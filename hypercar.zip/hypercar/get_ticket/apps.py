from django.apps import AppConfig


class GetTicketConfig(AppConfig):
    name = 'get_ticket'
